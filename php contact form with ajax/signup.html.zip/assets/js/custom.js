$(document).ready(function () {
    $("#form-signin").submit(function (event) {
        var formData = {
            name: $("#loginEmail").val(),
            email: $("#loginPassword").val()
        };
        $.ajax({
            type: "POST",
            url: "",
            data: formData,
            dataType: "json",
            encode: true,
        }).done(function (data) {
            // console.log('Successfully');
        }).fail(function (data) {
            // console.log('Fail');
            $( ".form-alert-msg" ).removeClass( "d-none" ).addClass( "d-block" );
        });

        event.preventDefault();
    });
});